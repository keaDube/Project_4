CREATE DATABASE MANAGEMENT_APP

USE MANAGEMENT_APP 

CREATE TABLE Users
(
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL,
    Surname NVARCHAR(50) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Contact NVARCHAR(20) NOT NULL
);


CREATE TABLE Modules (
    Code NVARCHAR(50) PRIMARY KEY,
    Name NVARCHAR(100),
    Credits INT,
    ClassHours INT
);

CREATE TABLE HoursRecords (
    RecordID INT PRIMARY KEY IDENTITY(1,1),
    ModuleCode NVARCHAR(50)FOREIGN KEY (ModuleCode) REFERENCES Modules(Code),
    RecordDate DATE,
    HoursWorked FLOAT, 
);



SELECT * FROM HoursRecords
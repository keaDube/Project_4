﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace managemet_app
{
    public partial class LOGIN : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // Hash the entered password
            string hashedPassword = HashPassword(password);

            // Query the database to check if the username and hashed password match
            string connectionString = "Data Source=DESKTOP-08OOCNT\\SQLEXPRESS;Initial Catalog=MANAGEMENT_APP;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Use parameterized queries to prevent SQL injection
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        lblMessage.Text = "Login successful!";
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                        // Redirect to the home page or perform other actions
                        Response.Redirect("MODULE.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Invalid username or password. Please try again.";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
            }
        }

        private string HashPassword(string password)
        {
            // Implement your hashing logic here
            // Example: using SHA-256
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
    }
}
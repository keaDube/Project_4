﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace managemet_app
{
    public partial class MODULE : System.Web.UI.Page
    {
        private List<Module> modules = new List<Module>();
        private Dictionary<string, List<RecordedHours>> hoursRecords = new Dictionary<string, List<RecordedHours>>();
        string connectionString = "Data Source=DESKTOP-08OOCNT\\SQLEXPRESS;Initial Catalog=MANAGEMENT_APP;Integrated Security=True;Encrypt=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Load modules from the database
                LoadModulesFromDatabase();
                // Initialize modules dropdown for recording hours
                BindModulesDropdown();
                // Display modules in the GridView
                BindModulesGridView();
            }
        }

        // all the buttons

        protected void btnAddModule_Click(object sender, EventArgs e)
        {
            // Add a new module to the database
            AddModuleToDatabase();

            // Display modules in the GridView
            BindModulesGridView();

            // Clear module input fields
            ClearModuleFields();
        }

        protected void btnRecordHours_Click(object sender, EventArgs e)
        {
            // Record hours worked for a specific module on a certain date
            string selectedModuleCode = ddlModules.SelectedValue;

            RecordHoursForModule(selectedModuleCode);
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            // Call a method to retrieve data from the database
            DataTable dt = GetModulesData();

            // Bind the data to the GridView
            if (dt != null && dt.Rows.Count > 0)
            {
                gvModules.DataSource = dt;
                gvModules.DataBind();
            }
            else
            {
                // Handle the case where no data is available
                // You might want to display a message or take appropriate action
            }
        }

        protected void btnCalculateRemainingHours_Click(object sender, EventArgs e)
        {
            // Ensure txtStartDate and txtWeeks have valid values
            if (!string.IsNullOrWhiteSpace(txtStartDate.Text) && !string.IsNullOrWhiteSpace(txtWeeks.Text))
            {
                DateTime startDate = DateTime.Parse(txtStartDate.Text);
                int weeks = int.Parse(txtWeeks.Text);

                // Calculate remaining self-study hours for each module and display in the GridView
                List<ModuleRemainingHours> remainingHoursList = new List<ModuleRemainingHours>();

                foreach (Module module in modules)
                {
                    double totalSelfStudyHours = (module.Credits * 10) / (double)(weeks - module.ClassHours);
                    double recordedHoursForWeek = GetRecordedHoursForCurrentWeek(module.Code);

                    double remainingHours = totalSelfStudyHours - recordedHoursForWeek;

                    remainingHoursList.Add(new ModuleRemainingHours
                    {
                        Code = module.Code,
                        RemainingHours = remainingHours
                    });
                }

                // Bind the data to the GridView
                if (remainingHoursList.Count > 0)
                {
                    gvModules.DataSource = remainingHoursList;
                    gvModules.DataBind();
                }
                else
                {
                    // Handle the case where no data is available
                    // You might want to display a message or take appropriate action
                    lblRemainingHoursMessage.Text = "No data available for the selected criteria.";
                }

                // Display a success message
                lblRemainingHoursMessage.Text = "Remaining hours calculated successfully!";
            }
            else
            {
                // Handle the case where txtStartDate or txtWeeks is empty or not valid
                // You may want to display an error message or take appropriate action
                lblRemainingHoursMessage.Text = "Invalid Start Date or Weeks. Please enter valid values.";
            }
        }




        private void BindDataToGridView(GridView gridView, DataTable dataTable)
        {
            if (dataTable != null && dataTable.Rows.Count > 0)
            {
                gridView.DataSource = dataTable;
                gridView.DataBind();
            }
            else
            {
                // Handle the case where no data is available
                // You might want to display a message or take appropriate action
            }
        }




        //all the methods to get infpormation from the database and use it 

        private DataTable GetModulesData()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString + ";TrustServerCertificate=True"))
            {
                connection.Open();
                string query = "SELECT Code, Name, Credits, ClassHours FROM Modules";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    // Fill the DataTable with the result set
                    adapter.Fill(dt);
                }
            }
            return dt;
        }


        private void LoadModulesFromDatabase()
        {
            // Load modules from the database and populate the modules list
            using (SqlConnection connection = new SqlConnection(connectionString + ";TrustServerCertificate=True"))
            {
                connection.Open();
                string query = "SELECT Code, Name, Credits, ClassHours FROM Modules";
                SqlCommand command = new SqlCommand(query, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Module module = new Module
                        {
                            Code = reader["Code"].ToString(),
                            Name = reader["Name"].ToString(),
                            Credits = Convert.ToInt32(reader["Credits"]),
                            ClassHours = Convert.ToInt32(reader["ClassHours"])
                        };

                        modules.Add(module);
                    }
                }
            }
        }

        private void AddModuleToDatabase()
        {
            // Add a new module to the database
            using (SqlConnection connection = new SqlConnection(connectionString + ";TrustServerCertificate=True"))
            {
                connection.Open();
                string query = "INSERT INTO Modules (Code, Name, Credits, ClassHours) VALUES (@Code, @Name, @Credits, @ClassHours)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Code", txtCode.Text);
                command.Parameters.AddWithValue("@Name", txtName.Text);
                command.Parameters.AddWithValue("@Credits", int.Parse(txtCredits.Text));
                command.Parameters.AddWithValue("@ClassHours", int.Parse(txtClassHours.Text));

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    // The module was successfully added to the database
                    lblMessage.Text = "Module added successfully!";
                    // You can also clear the input fields or perform other actions as needed
                    ClearModuleFields();
                }
                else
                {
                    // Handle the case where no rows were affected (e.g., insertion failed)
                    lblMessage.Text = "Failed to add module. Please try again.";
                }
            }
        }

        private void RecordHoursForModule(string moduleCode)
        {
            // Record hours worked for a specific module on a certain date
            using (SqlConnection connection = new SqlConnection(connectionString + ";TrustServerCertificate=True"))
            {
                connection.Open();
                string query = "INSERT INTO HoursRecords (ModuleCode, RecordDate, HoursWorked) VALUES (@ModuleCode, @RecordDate, @HoursWorked)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@ModuleCode", moduleCode);
                command.Parameters.AddWithValue("@RecordDate", DateTime.Parse(txtRecordDate.Text));
                command.Parameters.AddWithValue("@HoursWorked", double.Parse(txtHoursWorked.Text));

                int rowsAffected = command.ExecuteNonQuery();

                // Display a message based on the success of the operation
                if (rowsAffected > 0)
                {
                    // The hours were successfully added to the database
                    lblHoursMessage.Text = "Hours added successfully!";
                    // You can also clear the input fields or perform other actions as needed
                    ClearHoursFields();
                }
                else
                {
                    // Handle the case where no rows were affected (e.g., insertion failed)
                    lblHoursMessage.Text = "Failed to add hours. Please try again.";
                }
            }
        }


        private double GetRecordedHoursForCurrentWeek(string moduleCode)
        {
            // Calculate recorded hours for the current week for a specific module
            double recordedHoursForWeek = 0;

            if (hoursRecords.ContainsKey(moduleCode))
            {
                DateTime startDate = DateTime.Parse(txtStartDate.Text);
                DateTime currentDate = DateTime.Now;
                int currentWeek = (int)Math.Ceiling((currentDate - startDate).TotalDays / 7);

                foreach (RecordedHours recordedHours in hoursRecords[moduleCode])
                {
                    int recordedWeek = (int)Math.Ceiling((recordedHours.Date - startDate).TotalDays / 7);

                    if (recordedWeek == currentWeek)
                    {
                        recordedHoursForWeek += recordedHours.HoursWorked;
                    }
                }
            }

            return recordedHoursForWeek;
        }





        private void BindModulesDropdown()
        {
            // Bind modules to the dropdown list for recording hours
            ddlModules.DataSource = modules;
            ddlModules.DataTextField = "Code";
            ddlModules.DataValueField = "Code";
            ddlModules.DataBind();
        }

        private void BindModulesGridView()
        {
            // Display modules in the GridView
            gvModules.DataSource = modules;
            gvModules.DataBind();
        }






        private void ClearModuleFields()
        {
            // Clear module input fields
            txtCode.Text = string.Empty;
            txtName.Text = string.Empty;
            txtCredits.Text = string.Empty;
            txtClassHours.Text = string.Empty;

        }
        private void ClearHoursFields()
        {
            ddlModules.SelectedIndex = 0; // Assuming the first item is a default value
            txtRecordDate.Text = string.Empty;
            txtHoursWorked.Text = string.Empty;
        }



        //all the set and get methods

        public class Module
        {
            public string Code { get; set; }
            public string Name { get; set; }
            public int Credits { get; set; }
            public int ClassHours { get; set; }
        }

        public class RecordedHours
        {
            public DateTime Date { get; set; }
            public double HoursWorked { get; set; }
        }

        public class ModuleRemainingHours
        {
            public string Code { get; set; }
            public double RemainingHours { get; set; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace managemet_app
{
    public partial class REGISTER : System.Web.UI.Page
    {

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string surname = txtSurname.Text;
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;
            string contact = txtContact.Text;

            // Check if passwords match
            if (password != confirmPassword)
            {
                lblMessage.Text = "Passwords do not match.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // Hash the password before storing
            string hashedPassword = HashPassword(password);

            // Save user data to the database
            string connectionString = "Data Source=DESKTOP-08OOCNT\\SQLEXPRESS;Initial Catalog=MANAGEMENT_APP;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Use parameterized queries to prevent SQL injection
                string query = "INSERT INTO Users (Username, Surname, PasswordHash, Contact) VALUES (@Username, @Surname, @PasswordHash, @Contact)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    command.Parameters.AddWithValue("@Contact", contact);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblMessage.Text = "Registration successful!";
                        lblMessage.ForeColor = System.Drawing.Color.Green;
                        // Redirect to login page or perform any other actions
                        Response.Redirect("LOGIN.aspx");
                    }
                    else
                    {
                        lblMessage.Text = "Registration failed. Please try again.";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
            }
        }


        private string HashPassword(string password)
        {
            // Implement your hashing logic here
            // Example: using SHA-256
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
    }
}